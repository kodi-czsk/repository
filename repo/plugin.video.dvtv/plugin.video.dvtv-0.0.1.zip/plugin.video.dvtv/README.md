# Summary

DVTV.cz video plugin. Available videos are parsed from `https://video.aktualne.cz/rss/dvtv/`.

# Installation

## From zip file
Plugin can be installed manually from zip file:

1) Download repository in zip file by clicking on "Code" button and "Download ZIP"
2) Launch Kodi >> Add-ons >> Get More >> .. >> Install from downloaded zip file
