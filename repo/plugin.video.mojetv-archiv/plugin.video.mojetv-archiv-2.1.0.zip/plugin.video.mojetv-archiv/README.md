# plugin.video.mojetv-archiv  
Kodi Addon pre sprístupnenie Archivu MojeTV.  

Inštalácia a nastavenie
----------
1. Stiahnite tento repozitár ako .zip (tlačítko Download ZIP)
2. V kodi bežte do System->Addons->Install from zip file a nájdite stiahnutý zip súbor
3. Po úspešnom nainštalovaní bežte do Videos->Video add-ons Potom pravým tlačítkom, alebo klávesou C na klávesnici vyvolajte kontexové menu kde zvolťe Add-on settings a tu zadajte vaše meno a heslo k MojeTV. 
4. Užijte si archív :)
