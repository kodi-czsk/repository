﻿import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import urllib2
import cookielib
import re
import urlparse

"""
Create URL from query
"""
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

"""
Create channels folders
"""
def createChanelFolder():
    chanels = re.findall("(?<=<div class=\"int-team\">).*?(?=<span></span>)", page, re.DOTALL)
    chanelsLogos = re.findall("(?<=<img src=\").*?(?=<div class=\"team-hint team-hint-navi\">)", page, re.DOTALL)
    chanelsId = re.findall("(?<=<a href=\"\?id=).*?(?=\"><img src=)", page)

    for i in range(len(chanels)):
        chanelsLogo = re.sub("\" alt=\"\" />.*", "", chanelsLogos[i])
        chanelsLogo = "http://www.mojetv.net" + chanelsLogo.strip();
        chanel = re.sub(".*<b>", "", chanels[i])
        chanel = re.sub("</b>.*", "", chanel)

        url = build_url({'mode': 'chanel', 'chanelsId': chanelsId[i]})
        li = xbmcgui.ListItem(chanel, iconImage=chanelsLogo)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

"""
Create dates folders
"""
def createDaysFolder():
    dayNumbers = re.findall("(?<=<div class=\"ti-c-day\">).*?(?=</div>)", page)
    dayNames = re.findall("(?<=<div class=\"ti-c-month\">).*?(?=</div>)", page)
    dayIds = re.findall("(?<=<a href=\"\?den=).*?(?=&)", page)

    for i in range(len(dayNumbers)):
        dayName = re.sub("<b>", "!!! ", dayNames[i])
        dayName = re.sub("</b>", " !!!", dayName)
        chanelId = args['chanelsId'][0]
        url = build_url({'mode': 'date', 'chanelId': chanelId, 'dayId': dayIds[i]})
        li = xbmcgui.ListItem(dayName, iconImage="DefaultFolder.png")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

"""
Create videos
"""
def createVideos():
    videoUrls = re.findall("(?<=<a href=\").*(?=\" class=\"rec-link\"></a>)", page)
    titles = re.findall("(?<=<div class=\"newsrec-descr\">).*?(?=</div>)", page, re.DOTALL)
    thumbs = re.findall("(?<=<div class=\"newsrec\" style=\"background-image: url\().*?(?=\);)", page)

    for i in range(len(videoUrls)):
        title = re.sub(".*<em>", "", titles[i])
        title = re.sub("</em>.*", "", title)
        thumb = "http://www.mojetv.net" + thumbs[i]
        resp = opener.open('http://www.mojetv.net/' + videoUrls[i])
        url = resp.read()
        url = re.findall("(?<=<div id=\"player\"><video width=\"750\" height=\"460\" src=\").*(?=\" controls autoplay>)", url)
        li = xbmcgui.ListItem(title, iconImage=thumb)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url[0], listitem=li)

"""
Main program
"""
#Get login information of user fom setting xml
my_addon = xbmcaddon.Addon()
username = my_addon.getSetting('username')
password = my_addon.getSetting('password')

#Open web page, login ans save session
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
login_data = urllib.urlencode({'username' : username, 'password' : password})
opener.open('http://www.mojetv.net/login.php', login_data)

#Arguments of Addon
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

#Set content and mode
xbmcplugin.setContent(addon_handle, 'movies')
mode = args.get('mode', None)

"""
Pick mode
"""
#Pick TV chanel
if mode is None:
    resp = opener.open('http://www.mojetv.net/archiv.php')
    page = resp.read()
    createChanelFolder()
    xbmcplugin.endOfDirectory(addon_handle)
#Pick Date
elif mode[0] == 'chanel':
    resp = opener.open('http://www.mojetv.net/archiv.php')
    page = resp.read()
    createDaysFolder()
    xbmcplugin.endOfDirectory(addon_handle)
#Pick TV show
elif mode[0] == 'date':
    resp = opener.open('http://www.mojetv.net/archiv.php?den=' + args['dayId'][0] + '&id=' + args['chanelId'][0])
    page = resp.read()
    createVideos()
    xbmcplugin.endOfDirectory(addon_handle)

