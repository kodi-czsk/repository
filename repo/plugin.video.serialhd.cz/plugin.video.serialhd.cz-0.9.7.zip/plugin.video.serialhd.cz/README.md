# serialhd
Doplnok pre Serialhd.cz

@Martin Podkrivacky

0.9.7: 4 Testovacia verzia

0.9.6: 4 Testovacia verzia

0.9.5: 3 Testovacia verzia

0.9.4: 2 Testovacia verzia

0.9.3: 1 Testovacia verzia

0.9.1: Zmena webu

0.9.0: Initial version

Repozitár k doplnku: https://kodi.serialhd.cz/repository.playbe-1.0.0.zip
