### Prima Play Kodi Addon

Doplněk pro přehrávání videí z archivu Prima Play
