# plugin.video.dmd-czech.dvtv

Vývoj tohoto pluginu byl ukončen, DVTV je možno sledovat pomocí https://github.com/kodi-czsk/plugin.video.dmd-czech.aktualne
