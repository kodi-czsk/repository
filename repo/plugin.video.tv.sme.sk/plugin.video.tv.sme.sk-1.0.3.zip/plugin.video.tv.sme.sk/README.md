# plugin.video.tv.sme.sk

Video doplnok do [kodi](http://www.kodi.tv/) pre prehrávenie videí z archívu [tv.sme.sk](http://tv.sme.sk/).

Informácie o inštalácii sú dostupné na stránkach repozitára doplnkov [Kodi CZ/SK](http://kodi-czsk.github.io/repository/).
