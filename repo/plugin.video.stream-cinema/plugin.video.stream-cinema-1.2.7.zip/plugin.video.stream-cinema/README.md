# plugin.video.stream-cinema
kodi plugin pre stream-cinema.online

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UJE44M8YRL5ZQ)
