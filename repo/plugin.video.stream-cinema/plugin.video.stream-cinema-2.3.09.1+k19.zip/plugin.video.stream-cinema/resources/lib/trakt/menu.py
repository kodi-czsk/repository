from resources.lib.trakt.Trakt import trakt

class menu:
    def __init__(self):
        pass

    def root(self):
        pass
