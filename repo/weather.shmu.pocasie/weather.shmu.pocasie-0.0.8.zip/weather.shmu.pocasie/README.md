# weather.shmu.pocasie

Doplnok do Kodi/XBMC, ktory zobrazuje predpoved pocasia + meteogram zo SHMU.sk. Nakolko SHMU neposkytuje aktualne poveternostne podmienky, tieto sa preberaju zo servera openweathermap.org. Aby doplnok fungoval je potrebne sa (zdarma) na openweathermap.org zaregistrovat a v nastaveniach doplnku zadat vygenerovany API kluc (APPID).
