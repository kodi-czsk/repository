
# Skylink LiveTV CZ/SK
[![Download](https://img.shields.io/badge/download%20plugin-0.0.3-blue.svg?style=flat-square)](https://github.com/Sorien/plugin.video.sl/releases/download/0.0.3/plugin.video.sl.zip)
[![Releases Count](https://img.shields.io/github/downloads/Sorien/plugin.video.sl/0.0.3/total.svg?style=flat-square)](https://github.com/Sorien/plugin.video.sl/releases/tag/0.0.3)

Plugin generuje playlist a EPG pro službu Skylink LiveTV. Veškerá podpora je k dispozici na webu [XBMC-Kodi.cz](http://www.xbmc-kodi.cz/prispevek-skylink-livetv-addon-beta)
# Upozornění
Playlist funguje pouze v Kodi 18 Alpha2+/Nightly. Na některých mobilních telefonech může Kodi spadnout - Kodi 18 je ve vývoji.
