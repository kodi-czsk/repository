# Skylink LiveTV CZ/SK

Plugin generuje playlist a EPG pre službu Skylink LiveTV. Podpora je k dispozíci na webe [XBMC-Kodi.cz](http://www.xbmc-kodi.cz/prispevek-skylink-livetv-addon-beta)