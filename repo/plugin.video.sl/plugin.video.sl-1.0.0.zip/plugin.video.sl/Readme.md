
# Skylink LiveTV CZ/SK
[![Download](https://img.shields.io/badge/download%20plugin-0.0.6-blue.svg?style=flat-square)](https://github.com/Sorien/plugin.video.sl/releases/download/0.0.6/plugin.video.sl.zip)

Plugin generuje playlist a EPG pro službu Skylink LiveTV. Veškerá podpora je k dispozici na webu [XBMC-Kodi.cz](http://www.xbmc-kodi.cz/prispevek-skylink-livetv-addon-beta)
# Upozornění
Playlist funguje pouze v Kodi 18 Alpha2+/Nightly. Na některých zařízeních s Android může Kodi spadnout - Kodi 18 je ve vývoji.
