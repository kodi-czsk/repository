# plugin.video.tv.lux.sk
Video plugin for Kodi. Enables browsing of TV archive and watching a live stream of Slovak christian TV - TV Lux.