# coding=utf-8
import xbmc

def log(message):
    xbmc.log('|plugin.video.tipsport.elh|\t{0}'.format(message))
