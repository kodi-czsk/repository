# skin.estuary.stream-cinema
Modification and adaptation of basic Kodi skin Estuary for the popular addon Stream-Cinema CZ/SK.
Modifikace a adaptace základního skinu Kodi Estuary pro populární addon Stream-Cinema CZ/SK.

Skin je určený pro Kodi 17.x - Krypton.