# skin.estuary.stream-cinema
Skin je určený pro Kodi 17.x - Krypton.

Modifikace a adaptace základního skinu Kodi Estuary pro populární addon Stream-Cinema CZ/SK.

Skin vychází z originálu Estuary, verze 1.9.16
